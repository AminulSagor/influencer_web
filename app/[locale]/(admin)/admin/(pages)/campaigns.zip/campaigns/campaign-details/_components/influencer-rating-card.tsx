
import CollapsibleCard from "./collapsible-card";
import ClientRatingCard from "./client-rating-card";
import { CampaignStatusType } from "@/types/admin/campaign/campaign_details_type";

interface Props {
  campaignStatus: CampaignStatusType;
}

const clientRatings = [
  {
    id: 1,
    name: "Hania Amir",
    avatarUrl: "https://github.com/ninjastorm24.png",
    rating: 4,
  },
  {
    id: 2,
    name: "Ali Zafar",
    avatarUrl: "https://github.com/shadcn.png",
    rating: 5,
  },
];

const InfluencerRatingCard = ({ campaignStatus }: Props) => {
  return (
    <CollapsibleCard
      heading="Rating overview of the Influencers"
      badgeText={
        campaignStatus !== "needs-quote"
          ? "Campaign Has Not Finished Yet"
          : "Campaign Is Not Started Yet"
      }
    >
      {campaignStatus !== "needs-quote" ? (
        <div className="space-y-2">
          <div className="space-y-2">
            {clientRatings.map((client) => (
              <ClientRatingCard
                key={client.id}
                name={client.name}
                avatarUrl={client.avatarUrl}
                rating={client.rating}
              />
            ))}
          </div>
        </div>
      ) : (
        <div className="min-h-[300px] flex items-center justify-center">
          <p className="text-gray-400">Client needs to confirm the quote first</p>
        </div>
      )}
    </CollapsibleCard>
  );
};

export default InfluencerRatingCard;
