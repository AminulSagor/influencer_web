"use client";

import { useTranslations } from "next-intl";
import type { CampaignOverView } from "@/types/client/campaigns/campaign-overview";
import { Card, CardContent } from "@/components/ui/card";
import { FaClock } from "react-icons/fa";
import ListShell from "../list-shell";
import { getAssignedUserBasedText } from "@/app/[locale]/(brand)/brand/(pages)/campaigns/_lib/card-helpers";
import AvatarStack from "@/app/[locale]/(brand)/brand/(pages)/campaigns/_components/avatar-stack";
import { getPlatformIcon } from "@/utils/platforms_util";
import { formatDeadline } from "@/utils/date_util";

export default function CancelledCampaignsList({
  campaigns,
  loading,
}: {
  campaigns: CampaignOverView[];
  loading?: boolean;
}) {
  const t = useTranslations("brand.CampaignsPage");

  return (
    <ListShell
      loading={loading}
      empty={!loading && campaigns.length === 0}
      emptyTitle={t("noCancelledCampaignsFound")}
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 2xl:grid-cols-3 gap-4 mt-6">
        {campaigns.map((c) => (
          <CancelledCard key={c.id} c={c} />
        ))}
      </div>
    </ListShell>
  );
}

function CancelledCard({ c }: { c: CampaignOverView }) {
  const t = useTranslations("brand.CampaignsPage");

  const campaignType =
    c.campaignType === "paid_ad" ? t("paidAd") : t("influencerPromotion");

  const isAssigned = (c.assignedTo?.length ?? 0) > 0;
  const assignText = getAssignedUserBasedText(isAssigned, c.campaignType);

  return (
    <Card className="bg-white shadow-sm opacity-70 py-8">
      <CardContent className="space-y-4">
        <div className="space-y-1">
          <h3 className="text-dark-gray font-semibold leading-tight">
            {c.campaignName}
          </h3>
          <p className="text-dark-gray text-xs">{campaignType}</p>
        </div>

        <div className="flex gap-2 items-center">
          <AvatarStack users={c.assignedTo} />
          {!isAssigned && (
            <p className="text-xs text-dark-gray">{assignText}</p>
          )}
        </div>

        <div className="flex items-center gap-4">
          <p className="text-muted-foreground text-sm">{t("platforms")}</p>
          <div className="flex items-center gap-2">
            {c.platforms.length ? (
              c.platforms.map((p) => (
                <span
                  key={p}
                  className="leading-none p-1.5 rounded-md bg-light-green"
                >
                  {getPlatformIcon(p, "h-4 w-4 text-white")}
                </span>
              ))
            ) : (
              <span className="text-muted-foreground text-sm">—</span>
            )}
          </div>
        </div>

        <div className="rounded-xl border bg-muted/30 px-4 py-4 space-y-1">
          <p className="text-dark-gray">{t("offered")}</p>
          <p className="text-light-green text-3xl font-semibold">
            {c.totalBudget}
          </p>
        </div>

        <div className="flex items-center justify-between text-muted-foreground">
          <p className="flex items-center gap-2 text-sm">
            <FaClock />
            {t("deadline")}
          </p>
          <p className="text-sm">{formatDeadline(c.deadline)}</p>
        </div>
      </CardContent>
    </Card>
  );
}
